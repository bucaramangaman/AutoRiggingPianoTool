import os
import re
import sys
import ctypes 
#------------------------------------------

def get_bin_location():
    '''
    
    we want to find the bin fodler lcoation: C:/Program Files/Autodesk/Maya2019

    '''
    paths = os.environ['PATH'].split(';')
    for path in paths:
        search_result = re.search('Maya', path)
    if search_result:
        print search_result
    	return [path.split('/plug-ins')[0], path.split('/plug-ins')[0]+'//bin//mayapy.exe']

#print get_bin_location()[0]


def get_scripts_dir():
    '''
    find where your scripts are
    '''
    return cmds.internalVar(usd = True)
  
  
def is_admin():
    'are you admin of this pc?, we need to run maya as admin'
    try:
        return ctypes.windll.shell32.IsUserAnAdmin()
    except:
        return False  
   
     
def install_setup_tools():

    '''
    we need to isntall setup tools in order to install stuff from pypi.com
    for this one we need the bin lcoation
    be in a admin maya window
    have the local setup tools in the same folder in the scripts directory
    run the cmd for installing it with the console
    '''
    print get_bin_location()[0]+'/bin'
    
    #check admin rights before installing setup tools
    if is_admin():
        # Code of your program here
        print 'We have the admin in the house!!!'
    else:
        print 'no'
        
        cd = cmds.confirmDialog( title='Confirm', message='We need to close maya and start it again with admin privileges, agree? Just run the install again and thats it! Sorry for the inconvenience', 
        button=['Yes','No'], defaultButton='Yes', cancelButton='No', dismissString='No' )
        
        if cd == 'Yes':
            # Re-run the program with admin rights
            ctypes.windll.shell32.ShellExecuteW(None, u"runas", unicode(sys.executable), unicode(" ".join(sys.argv)), None, 1)
            cmds.quit(f=True)
        else:
            print ('user denied installing the stuff!'),   
            return 
                
    os.system('cmd /c "cd {}"'.format(get_bin_location()[0]+'/bin'))     
    #cd C:/Program Files/Autodesk/Maya2019/bin 
    install_path= get_scripts_dir() + '/pypi_install_maya/setuptools-38.5.1/setup.py'
    install = os.system('cmd /c "mayapy.exe {} install"'.format(install_path))    
    #mayapy.exe C:/Users/rodri/OneDrive/Documents/maya/2019/scripts/pipeline/setuptools-38.5.1/setup.py install
    if install == 0:
        print ('success install of setup tools'),


def custom_install_pip(pip='see', close=True):

    '''
    this will install your desire pypi module 
    you can close or not the console after installing
    '''
    
    #os version
    os.system('cmd /c "cd {}"'.format(get_bin_location()[0]+'/bin'))     
    #cd C:/Program Files/Autodesk/Maya2019/bin 
    install_path= get_scripts_dir() + '/pypi_install_maya/setuptools-38.5.1/easy_install.py'
    if close:
        install = os.system('cmd /c "mayapy.exe {} {}"'.format(install_path, pip))    
    else:
        install = os.system('cmd /k "mayapy.exe {} {}"'.format(install_path, pip))           
    #mayapy.exe C:/Users/rodri/OneDrive/Documents/maya/2019/scripts/pipeline/setuptools-38.5.1/setup.py install
    if install == 0:
        print ('Success Install {}'.format(pip)),
    

    #check here: 
    #C:\Program Files\Autodesk\Maya2019\Python\Lib\site-packages

#-----------------------------------

print ('installing setup tools'),
install_setup_tools()    #https://pypi.org/
#custom_install_pip(pip = 'see',close=True)

ask_what = cmds.promptDialog(
		title='Wha should we install in maya python?',
		message='Enter Name:',
		button=['Install and Close', 'Install and Remain ','Cancel'],
		defaultButton='OK',
		cancelButton='Cancel',
		dismissString='Cancel')

if ask_what == 'Install and Close':
	pip = cmds.promptDialog(query=True, text=True)
	custom_install_pip(pip = pip ,close=True)

if ask_what == 'Install and Remain ':
	pip = cmds.promptDialog(query=True, text=True)
	custom_install_pip(pip = pip ,close=False)

else:
    ('print Canceled'),   